import java.util.Scanner;
public class GPAtoGrade
{
    public static void main(String [] args){
    Scanner sc = new Scanner (System.in);
    System.out.println("Enter your GPA");
    double gpa = sc.nextDouble();
    if(gpa < 0.0 || gpa > 4.0){
        System.out.println("Please enter a valid GPA");
        sc.close();
        return;
    }
    String grade = " ";
    if (gpa <= 4.0 && gpa >= 3.6){
    grade = "A+";
    } else if (gpa < 3.6 && gpa >= 3.2){
        grade = "A";
    }else if (gpa < 3.2 && gpa >= 3.0){
        grade = "B+";
    }else if (gpa < 3.0 && gpa >= 2.8){
        grade = "B";
    }else if (gpa < 2.8 && gpa >= 2.6){
        grade = "C+";
    }else if (gpa < 2.6 && gpa >= 2.0){
        grade = "C";
    }else{
        grade = "F";
    }
    System.out.println(grade);
}
}