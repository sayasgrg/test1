import java.util.Scanner;
public class ClassRoutine
{
  public static void main(String [] args){
      Scanner sc= new Scanner(System.in);
      System.out.println("Enter the Day");
      String day = sc.next().toLowerCase();
      sc.close();
      switch(day){
          case "sunday" : System.out.println("Sunday Routine:Lecture, C Hardware and software, Programming");
          break;
          case "monday" : System.out.println("Monday Routine:Lecture, Information system, Logic");
          break;
          case "tuesday" : System.out.println("Tuesday Routine:Tutorial, Information system, Logic");
          break;
          case "wednesday" : System.out.println("Wednesday Routine:Tutorial, C Hardware and software, Programming");
          break;
          case "Thursday" : System.out.println("Thursday Routine:Workshop, C Hardware and software, Programming");
          break;
          case "Friday" : System.out.println("Friday Routine:Workshop, Information system, Logic");
          break;
          case "Saturday" : System.out.println("Holiday");
          break;
          default: System.out.println("Invalid Day");
      }
  }
}