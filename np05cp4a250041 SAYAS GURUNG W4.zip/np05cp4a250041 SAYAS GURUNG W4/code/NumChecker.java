import java.util.Scanner;
public class NumChecker
{
  public static void maiin (String [] args){
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter your Number");
      int num = sc.nextInt();
      if (num % 2 == 0){
          System.out.println("Even Number");
      }else{
          System.out.println("Odd number");
      }
  }
}