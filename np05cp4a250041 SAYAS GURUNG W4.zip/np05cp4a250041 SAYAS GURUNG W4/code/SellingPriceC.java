import java.util.Scanner;
public class SellingPriceC {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Marked Price: Rs. ");
        double markedPrice = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter Category (A, B, C, D): ");
        String category = scanner.nextLine().trim().toUpperCase();
        double discountRate = 0.0;
        switch (category) {
            case "A":
                discountRate = 0.60; break;
            case "B":
                discountRate = 0.40; break;
            case "C":
                discountRate = 0.20; break;
            case "D":
                discountRate = 0.10; break;
            default:
                System.out.println("Invalid Category. No discount applied.");
                break;
        }
        double discountAmount = markedPrice * discountRate;
        double sellingPrice = markedPrice - discountAmount;
        System.out.printf("Discount Applied: %.0f%%%n", discountRate * 100);
        System.out.printf("FINAL SELLING PRICE: Rs. %.2f%n", sellingPrice);

        scanner.close();
    }
}