import java.util.Scanner;
public class TaxBracket
{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your Income");
        double income = sc.nextDouble();
        sc.close();
        double tax = 0;
        if(income <= 500000){
            tax= income * 0.01;
        }else if(income <= 700000){
            tax= income * 0.1;
        }else if(income <= 1000000){
            tax= income * 0.2;
        }else if(income <= 2000000){
            tax= income * 0.3;
        }else if(income <= 5000000){
            tax= income * 0.36;
        }else{
            tax= income * 0.39;
        }
        System.out.printf("TAX is %.2f%n " , tax);
    }
}