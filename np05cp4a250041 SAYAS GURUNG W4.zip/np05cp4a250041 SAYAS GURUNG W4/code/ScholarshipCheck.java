import java.util.Scanner;
public class ScholarshipCheck
{
    public static void main(String [] args){
       Scanner sc= new Scanner (System.in);
       System.out.println("Enter your gpa" );
       double gpa = sc.nextDouble();
       if(gpa >= 3.2 ){
           System.out.println("Enter your attendence percentage");
       double attendence = sc.nextDouble();
           if (attendence >= 80){
                 System.out.println("Enter your attitude score");
       double attitudescore = sc.nextDouble();
               if (attitudescore >= 5){
                   System.out.println("You are eligible for scholarship");
               }else{
                   System.out.println("Attitude score too low");
               }
           }else{
                System.out.println("Attendace chai 80 mathi rakh");
            }
       }else{
           System.out.println("GPA too low");
       }
     }
    }