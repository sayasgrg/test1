import java.util.Scanner;
public class XFXCinema
{
   public static void main(String [] args){
       Scanner sc = new Scanner(System.in);
       double basepchild = 150;
       double basepadult = 250;
       double basepsenior = 200;
       double hindi = 50;
       double eng = 100;
       double stdd = 0.20;
       double fstd = 0.15;
       double finalPrice = 0;
       double surcharge = 0;
       System.out.println("Welcome to XFX Cinema");
       System.out.println("Enter your age group");
       String agegrp = sc.nextLine().trim().toLowerCase();
       switch (agegrp){
           case "child": finalPrice = basepchild; break;
           case "adult": finalPrice = basepadult; break;
           case "senior": finalPrice = basepsenior; break;
           default: System.out.println("Invalid age group, try again with child,adult,senior");
           main(args);
           return ;
       }
       System.out.println("Enter movie language");
       String lang = sc.nextLine().trim().toLowerCase();
       switch (lang){
           case "hindi": surcharge = hindi; break;
           case "english": surcharge = eng; break;
       }
       finalPrice += surcharge;
       System.out.println("Are you a student");
       String sdd = sc.nextLine().toLowerCase();
       if (sdd.equals("yes")){
           double disc1 = finalPrice * stdd;
           finalPrice -= disc1;
       }else{
           System.out.println("no student discount");
       }
       System.out.println("Is it festival today");
       String fes = sc.nextLine().toLowerCase();
       if (fes.equals("yes")){
           double disc2 = finalPrice * fstd;
           finalPrice -= disc2;
       }else{
           System.out.println("No festival discount");
       }
       System.out.printf("FINAL TICKET PRICE: Rs. %.2f%n", finalPrice);
   }
}